/* TrustVault role-console style: light editorial surfaces, restrained proof colors, and controls that reflect backend role boundaries. */
import { useEffect, useState } from "react";
import { ArrowRight, Ban, Check, ChevronRight, CircleAlert, FilePlus2, Lock, ShieldCheck, UserCog, WalletCards } from "lucide-react";
import { IdentityScene } from "./IdentityScene";

type Role = "user" | "admin" | "auditor";
type AdminView = "dashboard" | "users" | "roles" | "assets" | "audit";

type ConsoleProps = { role: Role };

const roleMeta: Record<Role, { label: string; eyebrow: string; title: string; intro: string }> = {
  user: { label: "USER", eyebrow: "OWNER CONSOLE / 02", title: "Your assets, your authority.", intro: "Create, verify, and control access to the assets attached to your identity." },
  admin: { label: "ADMIN", eyebrow: "SYSTEM CONSOLE / 00", title: "The trust layer, governed.", intro: "Manage users, roles, assets, and the consequences recorded across the system." },
  auditor: { label: "AUDITOR", eyebrow: "EVIDENCE CONSOLE / 06", title: "Every action leaves evidence.", intro: "Inspect audit activity and blockchain verification without mutation rights." },
};

type UserAsset = { name: string; type: string; date: string; status: string; id: string };
type UserActivity = [string, string, string];
type AccountState = { assets: UserAsset[]; activity: UserActivity[] };

const accountStorageKey = (email: string) => `trustvault.account.${email.trim().toLowerCase()}`;
const emptyAccount = (): AccountState => ({ assets: [], activity: [] });
const readAccount = (email: string): AccountState => {
  try {
    const saved = localStorage.getItem(accountStorageKey(email));
    if (!saved) return emptyAccount();
    const parsed = JSON.parse(saved) as Partial<AccountState>;
    return { assets: Array.isArray(parsed.assets) ? parsed.assets : [], activity: Array.isArray(parsed.activity) ? parsed.activity as UserActivity[] : [] };
  } catch {
    return emptyAccount();
  }
};

const auditRows = [
  ["30 Aug 2026 · 09:42", "Ishani Kaur", "Asset Created", "Identity passport", "AST-0001"],
  ["30 Aug 2026 · 09:31", "Ishani Kaur", "Blockchain Registered", "Ownership certificate", "AST-0002"],
  ["30 Aug 2026 · 09:14", "Arjun Mehta", "Access Granted", "Identity passport", "REQ-0019"],
  ["30 Aug 2026 · 08:58", "System admin", "User Role Changed", "Ishani Kaur", "USR-0007"],
];

function Stat({ label, value, note, accent = false }: { label: string; value: string; note: string; accent?: boolean }) {
  return <article className="console-stat"><span>{label}</span><strong className={accent ? "accent" : ""}>{value}</strong><small>{note}</small></article>;
}

function ConsoleHeader({ role }: ConsoleProps) {
  const meta = roleMeta[role];
  return <header className="console-header"><div><span className="console-kicker">{meta.eyebrow}</span><h1>{meta.title}</h1><p>{meta.intro}</p></div><div className="console-role-stamp"><span className="console-role-dot" />{meta.label}<small>ROLE VERIFIED</small></div></header>;
}

function ConsoleNav({ role }: ConsoleProps) {
  const items = role === "user" ? [["/console/user", "Dashboard"], ["/console/user/assets", "My Assets"], ["/console/user/create", "Create Asset"], ["/dashboard/identity", "My Identity"]] : role === "admin" ? [["/console/admin", "Admin Dashboard"], ["/console/admin/users", "User Management"], ["/console/admin/roles", "Role Management"], ["/console/admin/assets", "Asset Viewing"], ["/console/admin/audit", "Audit Logs"]] : [["/console/auditor", "Auditor Dashboard"], ["/console/auditor/assets", "Asset Verification"], ["/console/auditor/audit", "Audit Logs"], ["/console/auditor/blockchain", "Blockchain"]];
  return <nav className="console-nav">{items.map(([href, label]) => <a key={href} href={href} className={window.location.pathname === href ? "active" : ""}>{label}<ChevronRight size={13} /></a>)}</nav>;
}

function UserConsole({ email }: { email: string }) {
  const [account, setAccount] = useState<AccountState>(() => readAccount(email));
  useEffect(() => {
    setAccount(readAccount(email));
    const sync = (event: StorageEvent) => { if (event.key === accountStorageKey(email)) setAccount(readAccount(email)); };
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, [email]);
  const verifiedCount = account.assets.filter(asset => asset.status.toLowerCase().includes("verified")).length;
  return <><div className="console-stats"><Stat label="Total assets" value={String(account.assets.length).padStart(2, "0")} note="Attached to your DID" accent /><Stat label="Verified assets" value={String(verifiedCount).padStart(2, "0")} note="Registered on-chain" /><Stat label="Shared assets" value="00" note="Active access grant" /><Stat label="Recent activity" value={String(account.activity.length).padStart(2, "0")} note="Recorded events" /></div><div className="console-two-col"><section className="console-card"><div className="console-card-head"><div><span className="console-kicker">MY ASSETS / 01</span><h2>Owned resources.</h2></div><a className="console-link" href="/console/user/create">Create asset <ArrowRight size={13} /></a></div><div className="asset-list">{account.assets.length ? account.assets.map(asset => <article className="asset-row" key={asset.id}><div className="asset-icon"><WalletCards size={16} /></div><div className="asset-main"><strong>{asset.name}</strong><span>{asset.type} · {asset.date}</span></div><span className="verified-pill"><Check size={12} /> {asset.status}</span><a href={`/console/user/assets/${asset.id}`} className="icon-link" aria-label={`View ${asset.name}`}><ChevronRight size={16} /></a></article>) : <div className="empty-state"><strong>No assets attached yet.</strong><span>This account has no uploaded documents or ownership records.</span><a className="console-link" href="/console/user/create">Create your first asset <ArrowRight size={13} /></a></div>}</div></section><section className="console-card identity-mini-card"><div className="console-card-head"><div><span className="console-kicker">MY IDENTITY / CORE</span><h2>Protected by TrustVault.</h2></div></div><div className="identity-mini-scene"><IdentityScene /></div><a className="console-link identity-mini-link" href="/dashboard/identity">Open identity field <ArrowRight size={13} /></a></section></div><section className="console-card activity-card"><div className="console-card-head"><div><span className="console-kicker">ACTIVITY / RECENT</span><h2>What changed.</h2></div><a className="console-link" href="/console/user/audit">View all <ArrowRight size={13} /></a></div><div className="activity-list">{account.activity.length ? account.activity.map(([event, subject, when]) => <div className="activity-row" key={`${event}-${subject}`}><span className="activity-marker" /><div><strong>{event}</strong><span>{subject}</span></div><time>{when}</time></div>) : <div className="empty-state"><strong>No activity recorded yet.</strong><span>New actions for {email} will appear here.</span></div>}</div></section></>;
}

function AdminDashboard() {
  return <><div className="console-stats"><Stat label="Total users" value="08" note="Registered identities" accent /><Stat label="Total assets" value="24" note="Across all owners" /><Stat label="Verified assets" value="21" note="Blockchain registered" /><Stat label="Recent activity" value="14" note="Events in last 24h" /></div><div className="console-two-col"><section className="console-card"><div className="console-card-head"><div><span className="console-kicker">USER MANAGEMENT / 01</span><h2>People and roles.</h2></div><a className="console-link" href="/console/admin/users">Open directory <ArrowRight size={13} /></a></div><div className="user-list">{[["Ishani Kaur", "USER", "did:tv:0f64…408c0"], ["Arjun Mehta", "AUDITOR", "did:tv:98a1…1d02"], ["Naina Singh", "USER", "did:tv:6b31…c921"]].map(([name, role, did]) => <div className="user-row" key={name}><span className="user-avatar">{name[0]}</span><div><strong>{name}</strong><small>{did}</small></div><select defaultValue={role} aria-label={`Role for ${name}`}><option>USER</option><option>AUDITOR</option><option>ADMIN</option></select></div>)}</div></section><section className="console-card admin-activity"><div className="console-card-head"><div><span className="console-kicker">GOVERNANCE / 02</span><h2>Administrative boundary.</h2></div></div><div className="admin-boundary"><ShieldCheck size={20} /><p>Role changes are explicit, auditable, and restricted to this console. The frontend hides mutation controls from USER and AUDITOR accounts.</p></div><div className="permission-lines"><div><span>USER</span><strong>Own assets · manage access</strong></div><div><span>AUDITOR</span><strong>Read evidence · verify chain</strong></div><div><span>ADMIN</span><strong>Manage users · change roles</strong></div></div></section></div><section className="console-card activity-card"><div className="console-card-head"><div><span className="console-kicker">RECENT ACTIVITY / 03</span><h2>System consequences.</h2></div><a className="console-link" href="/console/admin/audit">Open audit logs <ArrowRight size={13} /></a></div><AuditTable rows={auditRows.slice(0, 3)} /></section></>;
}

function AdminConsole({ view }: { view: AdminView }) {
  if (view === "dashboard") return <AdminDashboard />;
  const page = {
    users: { kicker: "USER MANAGEMENT / 01", title: "People and roles.", intro: "Review registered identities and assign the correct authority boundary." },
    roles: { kicker: "ROLE MANAGEMENT / 02", title: "Permission boundaries.", intro: "Define which actions each role can perform across the TrustVault system." },
    assets: { kicker: "ASSET VIEWING / 03", title: "Every owned resource.", intro: "Inspect asset ownership, verification status, and the account behind each record." },
    audit: { kicker: "AUDIT LOGS / 04", title: "System consequences.", intro: "Review immutable events generated by identity, access, asset, and role actions." },
  }[view];
  const [revoked, setRevoked] = useState<Record<string, boolean>>(() => {
    try { return JSON.parse(localStorage.getItem("trustvault.admin.revocations") || "{}"); } catch { return {}; }
  });
  const [confirming, setConfirming] = useState<{ key: string; label: string } | null>(null);
  const [revokeAudit, setRevokeAudit] = useState<string[][]>(() => {
    try { return JSON.parse(localStorage.getItem("trustvault.admin.revokeAudit") || "[]"); } catch { return []; }
  });
  const confirmAccessChange = () => {
    if (!confirming) return;
    const restoring = Boolean(revoked[confirming.key]);
    const next = { ...revoked };
    if (restoring) delete next[confirming.key]; else next[confirming.key] = true;
    const action = restoring ? "Access Restored" : "Access Revoked";
    const event = [new Date().toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" }), "System admin", action, confirming.label, confirming.key];
    const nextAudit = [event, ...revokeAudit];
    setRevoked(next);
    setRevokeAudit(nextAudit);
    localStorage.setItem("trustvault.admin.revocations", JSON.stringify(next));
    localStorage.setItem("trustvault.admin.revokeAudit", JSON.stringify(nextAudit));
    setConfirming(null);
  };
  const users = [["Ishani Kaur", "USER", "did:tv:0f64…408c0", "ACTIVE"], ["Arjun Mehta", "AUDITOR", "did:tv:98a1…1d02", "ACTIVE"], ["Naina Singh", "USER", "did:tv:6b31…c921", "PENDING"], ["Kabir Shah", "ADMIN", "did:tv:31ef…f802", "ACTIVE"]];
  const assets = [["Identity passport", "Ishani Kaur", "DOCUMENT", "VERIFIED", "AST-0001"], ["Ownership certificate", "Ishani Kaur", "NFT / PROOF", "VERIFIED", "AST-0002"], ["Access manifest", "Naina Singh", "ACCESS", "PENDING", "AST-0003"], ["Research credential", "Arjun Mehta", "DOCUMENT", "VERIFIED", "AST-0004"]];
  const accessButton = (key: string, label: string) => <button className={revoked[key] ? "restore-button" : "revoke-button"} type="button" onClick={() => setConfirming({ key, label })}>{revoked[key] ? <Check size={13} /> : <Ban size={13} />} {revoked[key] ? "Restore access" : "Revoke access"}</button>;
  const isRestoring = confirming ? Boolean(revoked[confirming.key]) : false;
  return <section className="console-card admin-page"><div className="console-card-head"><div><span className="console-kicker">{page.kicker}</span><h2>{page.title}</h2><p>{page.intro}</p></div><a className="console-link" href="/console/admin">← Admin dashboard</a></div>{view === "users" && <div className="admin-directory"><div className="admin-toolbar"><strong>Registered identities</strong><span>08 accounts · revoke access available</span></div>{users.map(([name, role, did, status]) => <div className="admin-directory-row" key={name}><span className="user-avatar">{name[0]}</span><div><strong>{name}</strong><small>{did}</small></div><span className="role-pill">{role}</span><span className={`status-pill ${revoked[`user:${did}`] ? "revoked" : ""}`}>{revoked[`user:${did}`] ? "REVOKED" : status}</span>{accessButton(`user:${did}`, name)}</div>)}</div>}{view === "roles" && <div className="permission-matrix"><div className="matrix-row matrix-head"><span>Capability</span><span>USER</span><span>AUDITOR</span><span>ADMIN</span></div>{[["View own assets", "Allowed", "Allowed", "Allowed"], ["Create asset", "Allowed", "Blocked", "Allowed"], ["Grant access", "Allowed", "Blocked", "Allowed"], ["Verify blockchain", "Allowed", "Allowed", "Allowed"], ["Change user role", "Blocked", "Blocked", "Allowed"]].map(row => <div className="matrix-row" key={row[0]}>{row.map((cell, index) => <span key={`${row[0]}-${index}`} className={index > 0 ? cell === "Allowed" ? "allowed" : "blocked" : ""}>{cell}</span>)}</div>)}</div>}{view === "assets" && <div className="admin-asset-table"><div className="asset-table-head"><span>Asset</span><span>Owner</span><span>Type</span><span>Status</span><span>ID</span><span>Access</span></div>{assets.map(row => <div className="asset-table-row" key={row[4]}>{row.map((cell, index) => <span key={`${row[4]}-${index}`} className={index === 3 ? cell === "VERIFIED" ? "allowed" : "blocked" : ""}>{cell}</span>)}{accessButton(`asset:${row[4]}`, row[0])}</div>)}</div>}{view === "audit" && <AuditTable rows={[...revokeAudit, ...auditRows]} />}{confirming && <div className="revoke-confirm" role="alertdialog" aria-modal="true"><div><span className="console-kicker">ADMIN ACTION / CONFIRM</span><strong>{isRestoring ? "Restore access for" : "Revoke access for"} {confirming.label}?</strong><p>{isRestoring ? "This will restore the access relationship and create an audit event." : "This will mark the access relationship as revoked and create an audit event."} Continue only if this change is authorized.</p></div><div><button className={isRestoring ? "restore-confirm-button" : "revoke-confirm-button"} type="button" onClick={confirmAccessChange}>{isRestoring ? "Confirm restore" : "Confirm revoke"}</button><button className="cancel-submit" type="button" onClick={() => setConfirming(null)}>Cancel</button></div></div>}</section>;
}

function AuditorPage({ kicker, title, intro, children }: { kicker: string; title: string; intro: string; children: React.ReactNode }) {
  return <section className="console-card auditor-page"><div className="console-card-head"><div><span className="console-kicker">{kicker}</span><h2>{title}</h2><p>{intro}</p></div><a className="console-link" href="/console/auditor">← Auditor dashboard</a></div>{children}</section>;
}

function VerificationRows() {
  return <div className="verification-list"><div><span className="verification-status verified"><Check size={12} /></span><div><strong>Identity passport</strong><small>AST-0001 · tx: 0x8a2…f91</small></div><em>REGISTERED</em></div><div><span className="verification-status verified"><Check size={12} /></span><div><strong>Ownership certificate</strong><small>AST-0002 · tx: 0x44c…2a0</small></div><em>REGISTERED</em></div><div><span className="verification-status pending"><CircleAlert size={12} /></span><div><strong>Access manifest</strong><small>AST-0003 · awaiting registration</small></div><em>PENDING</em></div></div>;
}

function AuditorConsole() {
  const route = window.location.pathname;
  if (route === "/console/auditor/assets") return <AuditorPage kicker="ASSET VERIFICATION / 01" title="Proof status, inspected." intro="Review ownership records, chain registration, and the current verification state of every asset."><div className="auditor-record-list">{[["Identity passport", "Ishani Kaur", "AST-0001", "VERIFIED", "0x8a2…f91"], ["Ownership certificate", "Ishani Kaur", "AST-0002", "VERIFIED", "0x44c…2a0"], ["Access manifest", "Naina Singh", "AST-0003", "PENDING", "Awaiting registration"], ["Research credential", "Arjun Mehta", "AST-0004", "VERIFIED", "0x19d…7a4"]].map(([name, owner, id, status, proof]) => <article className="auditor-record" key={id}><div className={`verification-status ${status === "VERIFIED" ? "verified" : "pending"}`}>{status === "VERIFIED" ? <Check size={12} /> : <CircleAlert size={12} />}</div><div><strong>{name}</strong><span>{owner} · {id}</span><small>{proof}</small></div><em className={status === "VERIFIED" ? "allowed" : "blocked"}>{status}</em><span className="auditor-readonly-tag">READ ONLY</span></article>)}</div></AuditorPage>;
  if (route === "/console/auditor/audit") return <AuditorPage kicker="AUDIT LOGS / 02" title="Every action leaves evidence." intro="Inspect the immutable activity trail without changing identity, access, asset, or role records."><div className="auditor-filter-row"><span>06 EVENTS SHOWN</span><span><i className="state-dot" /> READ-ONLY VIEW</span></div><AuditTable rows={auditRows} /></AuditorPage>;
  if (route === "/console/auditor/blockchain") return <AuditorPage kicker="BLOCKCHAIN / 03" title="Chain state, readable." intro="Confirm that TrustVault records are anchored, traceable, and ready for independent review."><div className="chain-summary"><div><span>NETWORK</span><strong>TRUSTVAULT TESTNET</strong></div><div><span>LAST BLOCK</span><strong>#000001</strong></div><div><span>CONFIRMATIONS</span><strong>24 / 24</strong></div></div><div className="chain-records"><div><span className="verification-status verified"><Check size={12} /></span><div><strong>Identity passport</strong><small>Registered · block 000001 · 24 confirmations</small></div><em>ANCHORED</em></div><div><span className="verification-status verified"><Check size={12} /></span><div><strong>Ownership certificate</strong><small>Registered · block 000001 · 24 confirmations</small></div><em>ANCHORED</em></div><div><span className="verification-status pending"><CircleAlert size={12} /></span><div><strong>Access manifest</strong><small>Pending chain registration</small></div><em>PENDING</em></div></div></AuditorPage>;
  return <><div className="console-stats"><Stat label="Audit events" value="124" note="Inspectable records" accent /><Stat label="Verified assets" value="21" note="Blockchain registered" /><Stat label="Pending checks" value="03" note="Require review" /><Stat label="Mutation rights" value="00" note="Read-only role" /></div><div className="console-two-col"><section className="console-card"><div className="console-card-head"><div><span className="console-kicker">ASSET VERIFICATION / 01</span><h2>Proof status.</h2><p>Independent checks across the current TrustVault asset register.</p></div><a className="console-link" href="/console/auditor/assets">Open verification <ArrowRight size={13} /></a></div><VerificationRows /></section><section className="console-card read-only-card"><div className="console-card-head"><div><span className="console-kicker">AUDITOR BOUNDARY</span><h2>Inspect, never mutate.</h2><p>This console is intentionally read-only.</p></div></div><div className="read-only-message"><Ban size={20} /><p>Asset creation, deletion, access grants, and role changes are unavailable to this account.</p></div><div className="restricted-actions"><button disabled><FilePlus2 size={14} /> Create asset</button><button disabled><UserCog size={14} /> Change role</button><button disabled><Lock size={14} /> Grant access</button></div></section></div><section className="console-card activity-card"><div className="console-card-head"><div><span className="console-kicker">AUDIT LOG / 02</span><h2>Inspectable history.</h2><p>Recent evidence events from the TrustVault system.</p></div><a className="console-link" href="/console/auditor/audit">View full log <ArrowRight size={13} /></a></div><AuditTable rows={auditRows.slice(0, 3)} /></section></>;
}

function AuditTable({ rows }: { rows: string[][] }) {
  return <div className="audit-table"><div className="audit-head"><span>Timestamp</span><span>User</span><span>Action</span><span>Resource</span><span>Resource ID</span></div>{rows.map(row => <div className="audit-row" key={row.join("-")}>{row.map((cell, index) => <span key={`${cell}-${index}`}>{cell}</span>)}</div>)}</div>;
}

function CreateAssetPage({ email }: { email: string }) {
  const [form, setForm] = useState({ name: "", type: "VERIFIABLE DOCUMENT", description: "" });
  const [saved, setSaved] = useState(false);
  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const current = readAccount(email);
    const id = `AST-${String(Date.now()).slice(-4)}`;
    const asset: UserAsset = { name: form.name, type: form.type, date: "30 AUG 2026", status: "Pending verification", id };
    const next: AccountState = { assets: [...current.assets, asset], activity: [["Asset Created", form.name, "just now"], ...current.activity] };
    localStorage.setItem(accountStorageKey(email), JSON.stringify(next));
    setSaved(true);
  };
  return <section className="console-card create-asset-page"><div className="console-card-head"><div><span className="console-kicker">USER ASSET / NEW RECORD</span><h2>Create an asset.</h2></div><a className="console-link" href="/console/user">← Back to dashboard</a></div>{saved ? <div className="asset-success"><strong>{form.name} is attached to your identity.</strong><span>Record {readAccount(email).assets.at(-1)?.id || "created"} is saved for {email} and is awaiting verification.</span><a className="console-link" href="/console/user">View my assets <ArrowRight size={13} /></a></div> : <form className="asset-create-form" onSubmit={submit}><label><span>ASSET NAME</span><input required value={form.name} onChange={event => setForm({ ...form, name: event.target.value })} placeholder="e.g. Identity passport" /></label><label><span>ASSET TYPE</span><select value={form.type} onChange={event => setForm({ ...form, type: event.target.value })}><option>VERIFIABLE DOCUMENT</option><option>NFT / PROOF</option><option>ACCESS MANIFEST</option></select></label><label><span>DESCRIPTION</span><textarea required minLength={12} value={form.description} onChange={event => setForm({ ...form, description: event.target.value })} placeholder="Describe what this asset proves." /></label><div className="registration-actions"><button className="register-submit" type="submit">SAVE ASSET <ArrowRight size={15} /></button><a className="cancel-submit" href="/console/user">CANCEL</a></div></form>}</section>;
}

export function RoleConsole({ role }: ConsoleProps) {
  const meta = roleMeta[role];
  const adminPath = window.location.pathname.split("/").pop();
  const adminView: AdminView = adminPath === "users" ? "users" : adminPath === "roles" ? "roles" : adminPath === "assets" ? "assets" : adminPath === "audit" ? "audit" : "dashboard";
  let sessionEmail = "guest@trustvault.local";
  try {
    const session = JSON.parse(localStorage.getItem("trustvault.session") || "null") as { email?: string } | null;
    if (session?.email) sessionEmail = session.email;
  } catch {
    sessionEmail = "guest@trustvault.local";
  }
  return <div className="console-shell"><aside className="console-sidebar"><a className="console-brand" href="/"><span>◇</span><strong>TRUSTVAULT</strong><small>ROLE CONSOLE</small></a><div className="console-sidebar-role"><span className="console-role-dot" />{meta.label}<small>PERMISSION SCOPE</small></div><ConsoleNav role={role} /><a className="console-exit" href="/">← Exit to field</a></aside><main className="console-main"><ConsoleHeader role={role} />{role === "user" ? (window.location.pathname === "/console/user/create" ? <CreateAssetPage email={sessionEmail} /> : <UserConsole email={sessionEmail} />) : role === "admin" ? <AdminConsole view={adminView} /> : <AuditorConsole />}<footer className="console-footer"><span>TRUSTVAULT / {meta.label} / FRONTEND ROLE GUARD</span><span>BACKEND REMAINS SOURCE OF TRUTH</span></footer></main></div>;
}

export default RoleConsole;
